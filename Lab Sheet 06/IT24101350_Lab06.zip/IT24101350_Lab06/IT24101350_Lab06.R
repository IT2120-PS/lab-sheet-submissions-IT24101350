#Setting the directory
setwd("C:\\Users\\SARASI\\Downloads\\OneDrive\\Desktop\\SLIIT\\2nd Year\\PS")
getwd()

#Q1.1
#Random variable x has binomial distribution with n=50 and p=0.85

#Q1.2
pbinom(46, 50, 0.85, lower.tail =FALSE)

#Q2.1 
# x= number of calls received in one hour

#Q2.2 
#Random variable x has Poisson distribution with lambda =12

#Q2.3
dpois(15, 12)
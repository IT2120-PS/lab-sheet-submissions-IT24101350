setwd("C:\\Users\\IT24101350\\Downloads\\Lab 04-20250822\\IT24101350")
##  importing the Data Set
branch_data <- read.csv("Exercise.txt", header =TRUE)

##View the file in a seperate window
fix(branch_data)

##Attach the file into R
attach(branch_data)

##Branch - Ctegorical, Nominal
##Sales _X1 -Numerical continous, Ratio
#Advertising_X2 -Numerical continous, Ratio
## Years_X3 - Numerical Discrete , Ratio


##Boxplot
boxplot(Sales_X1, main = "Boxplot of Sales", outline =TRUE, outpch =8, horizontal =TRUE)

##Five Number summary
summary(branch_data&Advertising_X2)
IQR(branch_data$Advertising_X2)

get.outliers <- function(z)
{
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr<- q3 -q1
  
  ub<- q3 +1.5*iqr
  lb <- q1 -1.5*iqr
  
  print (paste("Upper Bound =", ub))
  print (paste("Lower Bound =", lb))
  print (paste("Outliers :", paste(sort(z[z<lb | z>ub]), collapse=", ")))
  
}

##Check Outliers
get.outliers(Years_X3)

